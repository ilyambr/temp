# homelab ssh access

## security rules

- never request, store, print, or place passwords, private keys, tokens, cookies, or other secrets in this repository.
- use the dedicated Codex SSH key at `C:\\Users\\Administrator\\.ssh\\codex_ed25519`. The private key stays local and is protected by its passphrase.
- use Tailscale addresses for homelab administration where available.
- new Codex accounts must be password-locked and key-only. Do not grant sudo access unless the task explicitly requires a minimal, reviewed sudo rule.

## verified server

- name: `anonymous-cat`
- OS: Arch Linux
- Tailscale IPv4: `100.105.244.117`
- account: `codex`
- status: key-only SSH verified on 2026-06-21; no sudo access configured.

From Windows PowerShell, test access with:

```powershell
ssh -i "$env:USERPROFILE\.ssh\codex_ed25519" -o IdentitiesOnly=yes codex@100.105.244.117 "whoami; cat /etc/hostname"
```

Expected output identifies `codex` and `anonymous-cat`. This minimal Arch install does not provide the `hostname` command, so use `cat /etc/hostname` for host-name checks.

## inventory

Read `HOMELAB_INVENTORY.md` before connecting to a homelab machine. It is a local-only inventory of host names, network addresses, and current access status. Update it whenever a server is onboarded or its address changes.

From Windows, `./Add-HomelabHost.ps1 -TailscaleIp <ip>` automatically records a host after its Codex SSH key is working, including graphical-interface availability.
It now also triggers a quiet sync of this workspace backup to `golden-retriever`.

For a new Linux server, run `./Provision-HomelabServer.ps1 -AdminUser <existing-admin> -TailscaleIp <ip>`. It creates the locked key-only `codex` account with the user-approved passwordless sudo rule, then verifies access and records the host in the local inventory.

For workspace backups, use `./Sync-HomelabBackup.ps1`. To keep a standing mirrored copy of this folder on the file server, run `powershell -ExecutionPolicy Bypass -File .\Watch-HomelabBackup.ps1` from this workspace on Windows.

## bootstrap commands for another Linux server

The user has approved full passwordless sudo for the `codex` account. Connect in Termius as an existing administrator, paste the command for the server OS, and enter the administrator password only at the sudo prompt.

### Arch Linux

```bash
set -e; if ! id -u codex >/dev/null 2>&1; then sudo useradd --create-home --shell /bin/bash --user-group codex; fi; sudo install -d -m 700 -o codex -g codex /home/codex/.ssh; printf '%s\n' 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK8eEklRCXGs52ZBMRWMTTKHLXGLAjJ7wGv/0ReKW6r2 codex@local' | sudo tee /home/codex/.ssh/authorized_keys >/dev/null; sudo chown codex:codex /home/codex/.ssh/authorized_keys; sudo chmod 600 /home/codex/.ssh/authorized_keys; sudo passwd --lock codex; printf '%s\n' 'codex ALL=(ALL:ALL) NOPASSWD: ALL' | sudo tee /etc/sudoers.d/codex >/dev/null; sudo chmod 440 /etc/sudoers.d/codex; sudo visudo -cf /etc/sudoers.d/codex; tailscale ip -4
```

### Debian

```bash
set -e; if ! id -u codex >/dev/null 2>&1; then sudo adduser --disabled-password --gecos "" --shell /bin/bash codex; fi; sudo install -d -m 700 -o codex -g codex /home/codex/.ssh; printf '%s\n' 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK8eEklRCXGs52ZBMRWMTTKHLXGLAjJ7wGv/0ReKW6r2 codex@local' | sudo tee /home/codex/.ssh/authorized_keys >/dev/null; sudo chown codex:codex /home/codex/.ssh/authorized_keys; sudo chmod 600 /home/codex/.ssh/authorized_keys; sudo passwd --lock codex; printf '%s\n' 'codex ALL=(ALL:ALL) NOPASSWD: ALL' | sudo tee /etc/sudoers.d/codex >/dev/null; sudo chmod 440 /etc/sudoers.d/codex; sudo visudo -cf /etc/sudoers.d/codex; tailscale ip -4
```

After it prints the Tailscale IP, update the local inventory with `Add-HomelabHost.ps1`.
