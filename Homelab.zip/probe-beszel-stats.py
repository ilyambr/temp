import sqlite3

conn = sqlite3.connect("/var/lib/beszel-hub/data.db")
print("types", [row[0] for row in conn.execute("select distinct type from system_stats order by type")])
print("counts", conn.execute("select type, count(*) from system_stats group by type order by type").fetchall())
print("latest")
for row in conn.execute("select system, type, created from system_stats order by created desc limit 20"):
    print(row)
