# homelab backup notes

this archive mirrors the workspace path:

`C:\Users\Administrator\Documents\Homelab`

on the file server under:

`/srv/samba/server/Codex Script Archive/C/Users/Administrator/Documents/Homelab`

## main files

- `AGENTS.md` - local operating notes for codex homelab access and onboarding.
- `HOMELAB_INVENTORY.md` - current local inventory of host names, addresses, and access state.
- `Add-HomelabHost.ps1` - windows helper that probes a linux host and updates the inventory.
- `Provision-HomelabServer.ps1` - windows helper that provisions the `codex` account on a new linux host, verifies ssh, and records it.
- `Sync-HomelabBackup.ps1` - one-shot sync that mirrors the current workspace files to the file server archive path on `golden-retriever`.
- `Watch-HomelabBackup.ps1` - local watcher that notices file changes in this folder and triggers `Sync-HomelabBackup.ps1` automatically after a short debounce.
- `host-dashboard-screensaver.c` - current custom mate lock-screen renderer used on `manager-parrot`.
- `host-dashboard-exporter.py` - beszel sqlite exporter that writes `/run/host-dashboard/beszel.tsv`.
- `host-dashboard-exporter.service` - systemd oneshot unit for the exporter.
- `host-dashboard-exporter.timer` - systemd timer that refreshes the exporter data every 15 seconds.
- `remove-test-disconnected.py` - one-off helper used to remove the fake `test-disconnected` system from the beszel hub database.

## manager-parrot install paths

- renderer binary: `/usr/libexec/mate-screensaver/host-dashboard`
- editable source copy: `/home/ilyambr/.local/src/host-dashboard-screensaver.c`
- exporter binary path: `/usr/local/libexec/host-dashboard-exporter`
- exporter units: `/etc/systemd/system/host-dashboard-exporter.service` and `/etc/systemd/system/host-dashboard-exporter.timer`
- mate screensaver desktop entry in use: `/usr/share/applications/screensavers/popsquares.desktop`

## redeploy commands

manual backup sync from windows:

```powershell
.\Sync-HomelabBackup.ps1
```

start the local auto-backup watcher from windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\Watch-HomelabBackup.ps1
```

from this workspace on windows, copy the latest renderer source to `manager-parrot`:

```powershell
scp -i "$env:USERPROFILE\.ssh\codex_ed25519" .\host-dashboard-screensaver.c codex@100.73.28.102:/home/codex/host-dashboard-screensaver.c
ssh -i "$env:USERPROFILE\.ssh\codex_ed25519" -o IdentitiesOnly=yes codex@100.73.28.102 'sudo -n sh -c '"'"'gcc /home/codex/host-dashboard-screensaver.c -o /tmp/host-dashboard $(pkg-config --cflags --libs cairo x11) -lm && install -m 755 /tmp/host-dashboard /usr/libexec/mate-screensaver/host-dashboard && install -o ilyambr -g ilyambr -m 644 /home/codex/host-dashboard-screensaver.c /home/ilyambr/.local/src/host-dashboard-screensaver.c'"'"''
```

copy the exporter and units:

```powershell
scp -i "$env:USERPROFILE\.ssh\codex_ed25519" .\host-dashboard-exporter.py codex@100.73.28.102:/home/codex/host-dashboard-exporter.py
scp -i "$env:USERPROFILE\.ssh\codex_ed25519" .\host-dashboard-exporter.service codex@100.73.28.102:/home/codex/host-dashboard-exporter.service
scp -i "$env:USERPROFILE\.ssh\codex_ed25519" .\host-dashboard-exporter.timer codex@100.73.28.102:/home/codex/host-dashboard-exporter.timer
ssh -i "$env:USERPROFILE\.ssh\codex_ed25519" -o IdentitiesOnly=yes codex@100.73.28.102 'sudo -n install -m 755 /home/codex/host-dashboard-exporter.py /usr/local/libexec/host-dashboard-exporter && sudo -n install -m 644 /home/codex/host-dashboard-exporter.service /etc/systemd/system/host-dashboard-exporter.service && sudo -n install -m 644 /home/codex/host-dashboard-exporter.timer /etc/systemd/system/host-dashboard-exporter.timer && sudo -n systemctl daemon-reload && sudo -n systemctl enable --now host-dashboard-exporter.timer && sudo -n systemctl restart host-dashboard-exporter.service'
```

refresh the live screensaver session after a renderer change:

```powershell
$envCmd = 'sudo -u ilyambr env DISPLAY=:0 XAUTHORITY=/home/ilyambr/.Xauthority XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus'
ssh -i "$env:USERPROFILE\.ssh\codex_ed25519" -o IdentitiesOnly=yes codex@100.73.28.102 "$envCmd mate-screensaver-command -d; sleep 1; $envCmd mate-screensaver-command -a"
```

## current behavior notes

- `Add-HomelabHost.ps1` now triggers a quiet backup sync after inventory updates.
- `Provision-HomelabServer.ps1` inherits that sync because it calls `Add-HomelabHost.ps1`.
- the watcher does an initial sync at startup, then resyncs this folder after local file changes.
- a Windows scheduled task named `Watch Homelab Backup` starts the watcher at logon so the mirror survives reboots and sign-ins.
- the lock screen uses live beszel data for cpu, battery, and state.
- disconnected systems render with a dim hostname and a centered red `disconnected` label.
- the renderer now paints to an offscreen back buffer first and only redraws on minute changes or real data changes, which reduced update flicker.
- `manager-parrot` is the only system tagged as `THIS MACHINE`.
