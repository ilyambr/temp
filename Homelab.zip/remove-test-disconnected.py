import sqlite3

DB = "/var/lib/beszel-hub/data.db"
TARGET = "test-disconnected"


def main():
    conn = sqlite3.connect(DB)
    try:
        row = conn.execute("select id from systems where name = ?", (TARGET,)).fetchone()
        if not row:
            print("not-found")
            return
        system_id = row[0]
        tables = []
        for (table,) in conn.execute(
            "select name from sqlite_master where type = 'table' and name not like 'sqlite_%'"
        ):
            columns = [column[1] for column in conn.execute(f"pragma table_info({table})")]
            if "system" in columns and table != "systems":
                tables.append(table)
        for table in tables:
            conn.execute(f"delete from {table} where system = ?", (system_id,))
        conn.execute("delete from systems where id = ?", (system_id,))
        conn.commit()
        print(f"deleted:{system_id}:{','.join(sorted(tables))}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
