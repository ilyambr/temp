[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TailscaleIp,

    [string]$KeyPath = (Join-Path $env:USERPROFILE '.ssh\codex_ed25519'),

    [string]$InventoryPath
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($InventoryPath)) {
    $InventoryPath = Join-Path $PSScriptRoot 'HOMELAB_INVENTORY.md'
}

if (-not (Test-Path -LiteralPath $KeyPath)) {
    throw "Codex SSH key was not found: $KeyPath"
}

if (-not (Test-Path -LiteralPath $InventoryPath)) {
    throw "Inventory file was not found: $InventoryPath"
}

function Invoke-CodexSsh {
    param([string[]]$RemoteArguments)

    $output = @(& ssh.exe -i $KeyPath -o IdentitiesOnly=yes "codex@$TailscaleIp" @RemoteArguments)
    if ($LASTEXITCODE -ne 0) {
        throw "SSH collection failed for $TailscaleIp. Verify that Codex key access works first."
    }

    return @($output | ForEach-Object { "$($_)".Trim() } | Where-Object { $_ })
}

$hostName = (Invoke-CodexSsh @('cat', '/etc/hostname') | Select-Object -First 1)
$osRelease = Invoke-CodexSsh @('cat', '/etc/os-release')
$osName = (($osRelease | Where-Object { $_ -match '^PRETTY_NAME=' } | Select-Object -First 1) -replace '^PRETTY_NAME=', '').Trim('"')
if ([string]::IsNullOrWhiteSpace($osName)) {
    $osName = (($osRelease | Where-Object { $_ -match '^ID=' } | Select-Object -First 1) -replace '^ID=', '').Trim('"')
}
$reportedTailscaleIp = (Invoke-CodexSsh @('tailscale', 'ip', '-4') | Select-Object -First 1)
$route = (Invoke-CodexSsh @('ip', 'route', 'get', '1.1.1.1')) -join ' '
$lanMatch = [regex]::Match($route, '\bsrc\s+(\S+)')
$lanIp = if ($lanMatch.Success) { $lanMatch.Groups[1].Value } else { 'unavailable' }

$graphicalTarget = (Invoke-CodexSsh @('systemctl', 'get-default') | Select-Object -First 1)
$displayManagerActive = (& ssh.exe -i $KeyPath -o IdentitiesOnly=yes "codex@$TailscaleIp" systemctl is-active display-manager 2>$null | Select-Object -First 1)
& ssh.exe -i $KeyPath -o IdentitiesOnly=yes "codex@$TailscaleIp" test -d /usr/share/xsessions 2>$null | Out-Null
$hasX11Sessions = $LASTEXITCODE -eq 0
& ssh.exe -i $KeyPath -o IdentitiesOnly=yes "codex@$TailscaleIp" test -d /usr/share/wayland-sessions 2>$null | Out-Null
$hasWaylandSessions = $LASTEXITCODE -eq 0
if ($displayManagerActive -eq 'active') {
    $graphicalInterface = 'available, active display manager'
} elseif ($hasX11Sessions -or $hasWaylandSessions) {
    $graphicalInterface = 'available, desktop sessions installed but display manager inactive'
} else {
    $graphicalInterface = "not available, no display manager or desktop sessions (default: $graphicalTarget)"
}

& ssh.exe -i $KeyPath -o IdentitiesOnly=yes "codex@$TailscaleIp" sudo -n true 2>$null | Out-Null
$codexSudo = if ($LASTEXITCODE -eq 0) { 'passwordless sudo verified' } else { 'none' }

if ([string]::IsNullOrWhiteSpace($hostName) -or [string]::IsNullOrWhiteSpace($reportedTailscaleIp)) {
    throw "Unexpected server response. Host name and Tailscale IP are required."
}
$hostName = $hostName.Replace('|', '/')
$osName = $osName.Replace('|', '/')
$reportedTailscaleIp = $reportedTailscaleIp.Replace('|', '/')
$lanIp = $lanIp.Replace('|', '/')
$today = Get-Date -Format 'yyyy-MM-dd'
$row = "| $hostName | $osName | ``$reportedTailscaleIp`` | ``$lanIp`` | verified key-only access | $codexSudo | $graphicalInterface | $today |"

$content = Get-Content -LiteralPath $InventoryPath -Raw
$marker = '<!-- hosts-table -->'
if (-not $content.Contains($marker)) {
    throw "Inventory table marker is missing: $marker"
}

$escapedHostName = [regex]::Escape($hostName)
$content = [regex]::Replace($content, "(?m)^\|\s*$escapedHostName\s*\|.*(?:\r?\n)?", '')
$content = $content.Replace($marker, "$row`r`n$marker")
Set-Content -LiteralPath $InventoryPath -Value $content -NoNewline

$syncScript = Join-Path $PSScriptRoot 'Sync-HomelabBackup.ps1'
if (Test-Path -LiteralPath $syncScript) {
    & $syncScript -Quiet
}

Write-Host "Updated $InventoryPath with $hostName ($reportedTailscaleIp, LAN $lanIp)."
