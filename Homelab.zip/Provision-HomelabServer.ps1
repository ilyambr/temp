[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$AdminUser,

    [Parameter(Mandatory)]
    [string]$TailscaleIp,

    [string]$KeyPath = (Join-Path $env:USERPROFILE '.ssh\codex_ed25519'),

    [string]$PublicKeyPath = (Join-Path $env:USERPROFILE '.ssh\codex_ed25519.pub')
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $KeyPath)) {
    throw "Codex private key was not found: $KeyPath"
}

if (-not (Test-Path -LiteralPath $PublicKeyPath)) {
    throw "Codex public key was not found: $PublicKeyPath"
}

$publicKey = (Get-Content -LiteralPath $PublicKeyPath -Raw).Trim()
if ($publicKey -notmatch '^ssh-ed25519\s+') {
    throw "Unexpected public-key format in $PublicKeyPath"
}

$publicKeyBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$publicKey`n"))
$linuxScript = @"
set -eu
if ! id -u codex >/dev/null 2>&1; then
    sudo useradd --create-home --shell /bin/bash --user-group codex
fi
sudo install -d -m 700 -o codex -g codex /home/codex/.ssh
echo '$publicKeyBase64' | base64 -d | sudo tee /home/codex/.ssh/authorized_keys >/dev/null
sudo chown codex:codex /home/codex/.ssh/authorized_keys
sudo chmod 600 /home/codex/.ssh/authorized_keys
sudo passwd --lock codex
echo 'codex ALL=(ALL:ALL) NOPASSWD: ALL' | sudo tee /etc/sudoers.d/codex >/dev/null
sudo chmod 440 /etc/sudoers.d/codex
sudo visudo -cf /etc/sudoers.d/codex
"@
$linuxScriptBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($linuxScript))
$remoteCommand = "echo '$linuxScriptBase64' | base64 -d | bash"

Write-Host "Connecting to $AdminUser@$TailscaleIp. Enter the existing administrator password only if sudo prompts for it."
& ssh.exe -tt "$AdminUser@$TailscaleIp" $remoteCommand
if ($LASTEXITCODE -ne 0) {
    throw "Linux provisioning failed for $TailscaleIp."
}

Write-Host 'Provisioning finished. Verifying Codex key access and updating the local inventory.'
& (Join-Path $PSScriptRoot 'Add-HomelabHost.ps1') -TailscaleIp $TailscaleIp -KeyPath $KeyPath
