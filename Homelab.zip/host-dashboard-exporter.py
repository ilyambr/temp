#!/usr/bin/env python3
import json
import os
import sqlite3
import tempfile

DATABASE = "/var/lib/beszel-hub/data.db"
OUTPUT = "/run/host-dashboard/beszel.tsv"


def short_os(name):
    if name.startswith("Arch Linux"):
        return "Arch Linux"
    if name.startswith("Debian GNU"):
        return "Debian GNU"
    return " ".join(name.split()[:2]) if name else "Linux"


def battery_state(value):
    return {
        2: "idle",
        3: "charging",
        4: "discharging",
        5: "idle",
    }.get(value, "unknown")


def main():
    connection = sqlite3.connect(f"file:{DATABASE}?mode=ro", uri=True)
    rows = connection.execute(
        """
        SELECT systems.id, systems.name, systems.host, COALESCE(system_details.os_name, '')
        FROM systems
        LEFT JOIN system_details ON system_details.system = systems.id
        ORDER BY CASE WHEN systems.name = 'manager-parrot' THEN 0 ELSE 1 END, systems.name
        """
    ).fetchall()

    directory = os.path.dirname(OUTPUT)
    os.makedirs(directory, mode=0o755, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", dir=directory, delete=False) as temporary:
        for system_id, name, tailscale_ip, os_name in rows:
            stat_row = connection.execute(
                """
                SELECT stats FROM system_stats
                WHERE system = ? AND type = '1m'
                ORDER BY created DESC LIMIT 1
                """,
                (system_id,),
            ).fetchone()
            if stat_row:
                stats = json.loads(stat_row[0])
                battery = stats.get("bat", [])
                percent = int(round(battery[0])) if battery else 0
                state = battery_state(battery[1]) if len(battery) > 1 else "unknown"
                cpu = float(stats.get("cpu", 0))
            else:
                percent = 0
                state = "disconnected"
                cpu = 0.0
            temporary.write(
                f"{name}\t{short_os(os_name)}\t{tailscale_ip}\t{percent}\t{state}\t{cpu:.1f}\n"
            )
        temporary_path = temporary.name

    os.chmod(temporary_path, 0o644)
    os.replace(temporary_path, OUTPUT)


if __name__ == "__main__":
    main()
