[CmdletBinding()]
param(
    [int]$DebounceSeconds = 8
)

$ErrorActionPreference = 'Stop'

$workspace = $PSScriptRoot
$syncScript = Join-Path $workspace 'Sync-HomelabBackup.ps1'
$watcher = [System.IO.FileSystemWatcher]::new($workspace)
$watcher.IncludeSubdirectories = $false
$watcher.Filter = '*.*'
$watcher.NotifyFilter = [System.IO.NotifyFilters]'FileName, LastWrite, CreationTime, Size'
$watcher.EnableRaisingEvents = $true

$script:pendingSync = $false
$script:lastEventAt = Get-Date

function Queue-Sync {
    $script:pendingSync = $true
    $script:lastEventAt = Get-Date
}

$handlers = @(
    (Register-ObjectEvent -InputObject $watcher -EventName Changed -Action { Queue-Sync }),
    (Register-ObjectEvent -InputObject $watcher -EventName Created -Action { Queue-Sync }),
    (Register-ObjectEvent -InputObject $watcher -EventName Renamed -Action { Queue-Sync }),
    (Register-ObjectEvent -InputObject $watcher -EventName Deleted -Action { Queue-Sync })
)

try {
    & $syncScript -Quiet
    while ($true) {
        Start-Sleep -Seconds 2
        if ($script:pendingSync -and ((Get-Date) - $script:lastEventAt).TotalSeconds -ge $DebounceSeconds) {
            $script:pendingSync = $false
            try {
                & $syncScript -Quiet
            }
            catch {
                Write-Warning $_
            }
        }
    }
}
finally {
    foreach ($handler in $handlers) {
        Unregister-Event -SubscriptionId $handler.Id -ErrorAction SilentlyContinue
        Remove-Job -Id $handler.Id -Force -ErrorAction SilentlyContinue
    }
    $watcher.Dispose()
}
