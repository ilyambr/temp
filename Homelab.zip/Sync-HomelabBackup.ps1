[CmdletBinding()]
param(
    [string]$KeyPath = (Join-Path $env:USERPROFILE '.ssh\codex_ed25519'),
    [string]$RemoteHost = 'codex@100.107.137.7',
    [string]$RemoteRoot = '/srv/samba/server/Codex Script Archive/C/Users/Administrator/Documents/Homelab',
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'

$workspace = $PSScriptRoot
$stagingZip = Join-Path $workspace 'homelab-backup.zip'
$remoteZip = '/home/codex/homelab-backup.zip'
$extensions = @('.md', '.ps1', '.py', '.service', '.timer', '.c', '.png')

function Write-Status {
    param([string]$Message)

    if (-not $Quiet) {
        Write-Host $Message
    }
}

if (-not (Test-Path -LiteralPath $KeyPath)) {
    throw "Codex SSH key was not found: $KeyPath"
}

$files = Get-ChildItem -LiteralPath $workspace -File |
    Where-Object { $_.Extension -in $extensions }

if (-not $files) {
    throw "No backup-eligible files were found in $workspace."
}

Write-Status "Creating backup bundle from $workspace"
Compress-Archive -Force -Path $files.FullName -DestinationPath $stagingZip

try {
    Write-Status "Ensuring archive path exists on $RemoteHost"
    & ssh.exe -i $KeyPath -o IdentitiesOnly=yes $RemoteHost "sudo -n mkdir -p '$RemoteRoot'"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to create remote archive path: $RemoteRoot"
    }

    Write-Status "Uploading backup bundle to $RemoteHost"
    & scp.exe -i $KeyPath $stagingZip "${RemoteHost}:${remoteZip}"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to upload backup bundle to $RemoteHost"
    }

    $extractScript = @"
import zipfile
from pathlib import Path
zip_path = Path(r"$remoteZip")
dest = Path(r"$RemoteRoot")
with zipfile.ZipFile(zip_path) as zf:
    zf.extractall(dest)
print(f"extracted {len(zf.namelist())} files")
zip_path.unlink(missing_ok=True)
"@

    Write-Status "Extracting bundle on $RemoteHost"
    @($extractScript) | & ssh.exe -i $KeyPath -o IdentitiesOnly=yes $RemoteHost "sudo -n python3 -"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to extract backup bundle on $RemoteHost"
    }

    Write-Status "Backup sync complete: $RemoteRoot"
}
finally {
    if (Test-Path -LiteralPath $stagingZip) {
        Remove-Item -LiteralPath $stagingZip -Force
    }
}
