# homelab inventory

Local-only file. It contains private network addressing and is intentionally excluded from git.

## hosts

| Host name | OS | Tailscale IPv4 | LAN IPv4 | Codex SSH | Codex sudo | Graphical interface | Last verified |
| --- | --- | --- | --- | --- | --- | --- | --- |
| anonymous-cat | Arch Linux | `100.105.244.117` | `192.168.1.158` | verified key-only access | passwordless sudo verified | not available, no display manager or desktop sessions | 2026-06-21 |
| anonymous-dog | Arch Linux | `100.102.57.127` | `192.168.1.157` | verified key-only access | passwordless sudo verified | not available, no display manager or desktop sessions | 2026-06-21 |
| calico-kitten | Arch Linux | `100.80.2.47` | `192.168.1.165` | verified key-only access | passwordless sudo verified | not available, no display manager or desktop sessions | 2026-06-21 |
| manager-parrot | Debian GNU/Linux 13 (trixie) | `100.73.28.102` | `192.168.1.166` | verified key-only access | passwordless sudo verified | available, active display manager with X11 sessions | 2026-06-21 |
| golden-retriever | Arch Linux | `100.107.137.7` | `192.168.1.203` | verified key-only access | passwordless sudo verified | not available, no display manager or desktop sessions | 2026-06-21 |
<!-- hosts-table -->

## automatic collection

From Windows PowerShell, run `./Add-HomelabHost.ps1 -TailscaleIp <ip>` after Codex key access is working. The script collects the host name, OS, Tailscale IP, primary LAN IP, passwordless-sudo status, and graphical-interface availability, then updates this table.
