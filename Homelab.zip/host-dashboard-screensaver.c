#include <X11/Xlib.h>
#include <cairo/cairo-xlib.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define BESZEL_CACHE "/run/host-dashboard/beszel.tsv"
#define MAX_BESZEL_SYSTEMS 8

typedef struct {
    char name[128];
    char os[64];
    char tailscale_ip[64];
    char battery[32];
    char state[32];
    double cpu;
} beszel_system_t;

static void trim(char *s) {
    size_t n = strlen(s);
    while (n > 0 && isspace((unsigned char)s[n - 1])) {
        s[--n] = '\0';
    }
    char *p = s;
    while (*p && isspace((unsigned char)*p)) {
        p++;
    }
    if (p != s) {
        memmove(s, p, strlen(p) + 1);
    }
}

static void run_line(const char *cmd, char *buf, size_t size, const char *fallback) {
    FILE *fp = popen(cmd, "r");
    if (!fp) {
        snprintf(buf, size, "%s", fallback);
        return;
    }
    if (!fgets(buf, (int)size, fp)) {
        snprintf(buf, size, "%s", fallback);
    }
    pclose(fp);
    trim(buf);
    if (buf[0] == '\0') {
        snprintf(buf, size, "%s", fallback);
    }
}

static int load_beszel_systems(beszel_system_t *systems, int capacity) {
    FILE *fp = fopen(BESZEL_CACHE, "r");
    if (!fp) {
        return 0;
    }

    int count = 0;
    char line[512];
    while (count < capacity && fgets(line, sizeof(line), fp)) {
        char *fields[6];
        char *field = strtok(line, "\t\r\n");
        int field_count = 0;
        while (field && field_count < 6) {
            fields[field_count++] = field;
            field = strtok(NULL, "\t\r\n");
        }
        if (field_count != 6) {
            continue;
        }

        snprintf(systems[count].name, sizeof(systems[count].name), "%s", fields[0]);
        snprintf(systems[count].os, sizeof(systems[count].os), "%s", fields[1]);
        snprintf(systems[count].tailscale_ip, sizeof(systems[count].tailscale_ip), "%s", fields[2]);
        snprintf(systems[count].battery, sizeof(systems[count].battery), "%s", fields[3]);
        snprintf(systems[count].state, sizeof(systems[count].state), "%s", fields[4]);
        systems[count].cpu = strtod(fields[5], NULL);
        count++;
    }
    fclose(fp);
    return count;
}

static int same_beszel_systems(const beszel_system_t *a, int a_count,
                               const beszel_system_t *b, int b_count) {
    if (a_count != b_count) {
        return 0;
    }
    for (int i = 0; i < a_count; i++) {
        if (strcmp(a[i].name, b[i].name) != 0 ||
            strcmp(a[i].os, b[i].os) != 0 ||
            strcmp(a[i].tailscale_ip, b[i].tailscale_ip) != 0 ||
            strcmp(a[i].battery, b[i].battery) != 0 ||
            strcmp(a[i].state, b[i].state) != 0 ||
            fabs(a[i].cpu - b[i].cpu) > 0.05) {
            return 0;
        }
    }
    return 1;
}

static void set_rgba(cairo_t *cr, double r, double g, double b, double a) {
    cairo_set_source_rgba(cr, r, g, b, a);
}

static void draw_text(cairo_t *cr, const char *text, double x, double y, double size,
                      int bold, double r, double g, double b, double a) {
    cairo_save(cr);
    cairo_select_font_face(cr, "DejaVu Sans", CAIRO_FONT_SLANT_NORMAL,
                           bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
    set_rgba(cr, r, g, b, a);
    cairo_text_extents_t ext;
    cairo_text_extents(cr, text, &ext);
    cairo_move_to(cr, x, y + ext.height);
    cairo_show_text(cr, text);
    cairo_restore(cr);
}

static void draw_text_right(cairo_t *cr, const char *text, double right_x, double y,
                            double size, int bold, double r, double g, double b, double a) {
    cairo_save(cr);
    cairo_select_font_face(cr, "DejaVu Sans", CAIRO_FONT_SLANT_NORMAL,
                           bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
    set_rgba(cr, r, g, b, a);
    cairo_text_extents_t ext;
    cairo_text_extents(cr, text, &ext);
    cairo_move_to(cr, right_x - ext.width - ext.x_bearing, y + ext.height);
    cairo_show_text(cr, text);
    cairo_restore(cr);
}

static void draw_text_center(cairo_t *cr, const char *text, double center_x, double y,
                             double size, int bold, double r, double g, double b, double a) {
    cairo_save(cr);
    cairo_select_font_face(cr, "DejaVu Sans", CAIRO_FONT_SLANT_NORMAL,
                           bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
    set_rgba(cr, r, g, b, a);
    cairo_text_extents_t ext;
    cairo_text_extents(cr, text, &ext);
    cairo_move_to(cr, center_x - ((ext.width + ext.x_bearing) * 0.5), y + ext.height);
    cairo_show_text(cr, text);
    cairo_restore(cr);
}

static double text_advance(const char *text, double size, int bold) {
    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 1, 1);
    cairo_t *cr = cairo_create(surface);
    cairo_select_font_face(cr, "DejaVu Sans", CAIRO_FONT_SLANT_NORMAL,
                           bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
    cairo_text_extents_t ext;
    cairo_text_extents(cr, text, &ext);
    cairo_destroy(cr);
    cairo_surface_destroy(surface);
    return ext.x_advance;
}

static void rounded_rect(cairo_t *cr, double x, double y, double w, double h, double radius) {
    double r = radius;
    cairo_new_sub_path(cr);
    cairo_arc(cr, x + w - r, y + r, r, -M_PI / 2.0, 0);
    cairo_arc(cr, x + w - r, y + h - r, r, 0, M_PI / 2.0);
    cairo_arc(cr, x + r, y + h - r, r, M_PI / 2.0, M_PI);
    cairo_arc(cr, x + r, y + r, r, M_PI, 3.0 * M_PI / 2.0);
    cairo_close_path(cr);
}

static void draw_card(cairo_t *cr, double x, double y, double w, double h,
                      double accent) {
    rounded_rect(cr, x, y, w, h, 18);
    set_rgba(cr, 0.035, 0.035, 0.035, 0.92);
    cairo_fill_preserve(cr);
    cairo_set_line_width(cr, 1.4);
    set_rgba(cr, 0.22, 0.22, 0.22, 0.55);
    cairo_stroke(cr);

    cairo_rectangle(cr, x, y, 5, h);
    set_rgba(cr, accent, accent, accent, 0.86);
    cairo_fill(cr);
}

static void draw_progress_bar(cairo_t *cr, double x, double y, double w, double h,
                              double percent, double r, double g, double b) {
    percent = fmax(0.0, fmin(100.0, percent));
    rounded_rect(cr, x, y, w, h, h / 2.0);
    set_rgba(cr, 0.12, 0.12, 0.12, 0.92);
    cairo_fill(cr);

    double filled = w * percent / 100.0;
    if (filled > 0.0) {
        rounded_rect(cr, x, y, fmax(h, filled), h, h / 2.0);
        set_rgba(cr, r, g, b, 0.95);
        cairo_fill(cr);
    }
}

static void draw_beszel_panel(cairo_t *cr, int width, int height, double margin,
                              const beszel_system_t *systems, int system_count) {
    if (system_count <= 0) {
        return;
    }

    double panel_w = fmin(520.0, width * 0.36);
    double x = width - margin - panel_w;
    double y = margin;
    double row_h = 88.0;
    double gap = 12.0;

    draw_text(cr, "HOMELAB", x, y, 28, 1, 0.62, 0.62, 0.62, 0.90);
    draw_text(cr, "LIVE SYSTEM STATUS", x + 3, y + 34, 16, 1, 0.45, 0.45, 0.45, 0.90);
    y += 62.0;

    for (int i = 0; i < system_count; i++) {
        const beszel_system_t *system = &systems[i];
        int is_disconnected = strcmp(system->state, "disconnected") == 0;
        draw_text(cr, system->name, x, y + 4, 23, 1, 0.76, 0.76, 0.76,
                  is_disconnected ? 0.42 : 0.96);
        if (!is_disconnected) {
            draw_text(cr, system->os, x, y + 34, 16, 0, 0.48, 0.48, 0.48, 0.92);
        }
        if (!is_disconnected && strcmp(system->name, "manager-parrot") == 0) {
            draw_text(cr, "THIS MACHINE", x + panel_w - 118, y + 8, 13, 1,
                      0.45, 0.62, 0.88, 0.92);
        } else if (!is_disconnected) {
            draw_text_right(cr, system->tailscale_ip, x + panel_w - 12, y + 8, 13, 1,
                            0.45, 0.62, 0.88, 0.92);
        }

        double state_r = 0.30, state_g = 0.60, state_b = 0.96;
        if (strcmp(system->state, "charging") == 0) {
            state_r = 0.30;
            state_g = 0.78;
            state_b = 0.42;
        } else if (strcmp(system->state, "discharging") == 0) {
            state_r = 0.88;
            state_g = 0.28;
            state_b = 0.28;
        } else if (strcmp(system->state, "disconnected") == 0) {
            state_r = 0.88;
            state_g = 0.28;
            state_b = 0.28;
        }

        if (is_disconnected) {
            draw_text_center(cr, "disconnected", x + (panel_w * 0.5), y + 44, 30, 1,
                             state_r, state_g, state_b, 0.98);
            y += row_h + gap;
            continue;
        }

        char cpu_text[48], percent_text[24];
        snprintf(cpu_text, sizeof(cpu_text), "CPU %.0f%%", system->cpu);
        snprintf(percent_text, sizeof(percent_text), "%s%%", system->battery);
        draw_text(cr, cpu_text, x, y + 56, 18, 1, 0.70, 0.70, 0.70, 0.94);
        double bar_x = x + panel_w * 0.48;
        double bar_w = panel_w * 0.49;
        draw_text(cr, percent_text, bar_x, y + 56, 17, 1,
                  state_r, state_g, state_b, 0.96);
        draw_text_right(cr, system->state, bar_x + bar_w, y + 56, 17, 1,
                        state_r, state_g, state_b, 0.96);
        draw_progress_bar(cr, bar_x, y + 78, bar_w, 8.0,
                          strtod(system->battery, NULL), state_r, state_g, state_b);
        y += row_h + gap;
    }
}

static void draw_dashboard(cairo_t *cr, int width, int height, const char *host,
                           const char *normal_ip, const char *tailscale_ip,
                           const beszel_system_t *systems, int system_count) {
    set_rgba(cr, 0, 0, 0, 1);
    cairo_rectangle(cr, 0, 0, width, height);
    cairo_fill(cr);

    set_rgba(cr, 0.08, 0.08, 0.08, 0.45);
    cairo_set_line_width(cr, 1);
    int spacing = 42;
    for (int x = -spacing; x < width + spacing; x += spacing) {
        cairo_move_to(cr, x, 0);
        cairo_line_to(cr, x - height * 0.25, height);
    }
    for (int y = -spacing; y < height + spacing; y += spacing) {
        cairo_move_to(cr, 0, y);
        cairo_line_to(cr, width, y + width * 0.25);
    }
    cairo_stroke(cr);

    time_t raw = time(NULL);
    struct tm tm_now;
    localtime_r(&raw, &tm_now);
    char clock_text[32], clock_suffix[8], date_text[128];
    strftime(clock_text, sizeof(clock_text), "%I:%M", &tm_now);
    strftime(clock_suffix, sizeof(clock_suffix), "%p", &tm_now);
    if (clock_text[0] == '0') {
        memmove(clock_text, clock_text + 1, strlen(clock_text));
    }
    for (char *p = clock_suffix; *p; p++) {
        *p = (char)tolower((unsigned char)*p);
    }
    strftime(date_text, sizeof(date_text), "%A, %B %e, %Y", &tm_now);
    for (char *p = date_text; *p; p++) {
        if (*p == ' ' && *(p + 1) == ' ') {
            memmove(p, p + 1, strlen(p));
        }
    }

    double margin = fmax(54.0, fmin(width, height) * 0.065);
    draw_text(cr, host, margin, margin, 28, 1, 0.62, 0.62, 0.62, 0.90);
    draw_text(cr, clock_text, margin, margin + 58, 132, 1, 0.82, 0.82, 0.82, 0.96);
    draw_text(cr, clock_suffix, margin + text_advance(clock_text, 132, 1) + 18, margin + 92,
              66, 1, 0.82, 0.82, 0.82, 0.96);
    draw_text(cr, date_text, margin + 6, margin + 185, 34, 1, 0.56, 0.56, 0.56, 0.92);

    double base_y = height - margin - 140.0;
    draw_text(cr, "NORMAL IP", margin, base_y + 18, 17, 1, 0.45, 0.45, 0.45, 0.90);
    draw_text(cr, normal_ip, margin, base_y + 45, 34, 1, 0.72, 0.72, 0.72, 0.96);

    draw_text(cr, "TAILSCALE IP", margin, base_y + 90, 17, 1, 0.45, 0.45, 0.45, 0.90);
    draw_text(cr, tailscale_ip, margin, base_y + 117, 34, 1, 0.70, 0.70, 0.70, 0.96);

    draw_beszel_panel(cr, width, height, margin, systems, system_count);
}

int main(int argc, char **argv) {
    char host[256], normal_ip[128], tailscale_ip[128];
    beszel_system_t systems[MAX_BESZEL_SYSTEMS];
    beszel_system_t next_systems[MAX_BESZEL_SYSTEMS];
    gethostname(host, sizeof(host));
    host[sizeof(host) - 1] = '\0';
    run_line("ip -4 -o addr show scope global | awk '$2 != \"tailscale0\" && $4 !~ /^100\\\\.64\\\\./ { split($4,a,\"/\"); print a[1]; exit }'",
             normal_ip, sizeof(normal_ip), "offline");
    run_line("tailscale ip -4 2>/dev/null | head -n1 || ip -4 -o addr show dev tailscale0 | awk '{ split($4,a,\"/\"); print a[1]; exit }'",
             tailscale_ip, sizeof(tailscale_ip), "offline");
    int system_count = load_beszel_systems(systems, MAX_BESZEL_SYSTEMS);

    if (argc > 1 && strcmp(argv[1], "--dump") == 0) {
        printf("host=%s\nnormal_ip=%s\ntailscale_ip=%s\n", host, normal_ip, tailscale_ip);
        return 0;
    }

    Display *display = XOpenDisplay(NULL);
    if (!display) {
        fprintf(stderr, "Unable to open X display\n");
        return 1;
    }

    const char *window_env = getenv("XSCREENSAVER_WINDOW");
    Window window;
    if (window_env && *window_env) {
        window = (Window)strtoul(window_env, NULL, 0);
    } else {
        int screen = DefaultScreen(display);
        window = XCreateSimpleWindow(display, RootWindow(display, screen), 0, 0,
                                     DisplayWidth(display, screen), DisplayHeight(display, screen),
                                     0, 0, BlackPixel(display, screen));
        XMapRaised(display, window);
    }

    XSelectInput(display, window, ExposureMask | StructureNotifyMask);

    XWindowAttributes attrs;
    XGetWindowAttributes(display, window, &attrs);
    cairo_surface_t *surface = cairo_xlib_surface_create(display, window, attrs.visual, attrs.width, attrs.height);
    cairo_t *cr = cairo_create(surface);
    cairo_surface_t *back_surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, attrs.width, attrs.height);
    cairo_t *back_cr = cairo_create(back_surface);

    int counter = 0;
    int last_minute = -1;
    int needs_redraw = 1;
    for (;;) {
        while (XPending(display)) {
            XEvent ev;
            XNextEvent(display, &ev);
            if (ev.type == Expose) {
                needs_redraw = 1;
            }
            if (ev.type == ConfigureNotify) {
                XConfigureEvent *cfg = &ev.xconfigure;
                cairo_xlib_surface_set_size(surface, cfg->width, cfg->height);
                cairo_destroy(back_cr);
                cairo_surface_destroy(back_surface);
                back_surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, cfg->width, cfg->height);
                back_cr = cairo_create(back_surface);
                needs_redraw = 1;
            }
        }

        XGetWindowAttributes(display, window, &attrs);
        time_t now = time(NULL);
        struct tm tm_now;
        localtime_r(&now, &tm_now);
        if (tm_now.tm_min != last_minute) {
            last_minute = tm_now.tm_min;
            needs_redraw = 1;
        }
        if (counter % 15 == 0) {
            char next_normal_ip[128], next_tailscale_ip[128];
            run_line("ip -4 -o addr show scope global | awk '$2 != \"tailscale0\" && $4 !~ /^100\\\\.64\\\\./ { split($4,a,\"/\"); print a[1]; exit }'",
                     next_normal_ip, sizeof(next_normal_ip), "offline");
            run_line("tailscale ip -4 2>/dev/null | head -n1 || ip -4 -o addr show dev tailscale0 | awk '{ split($4,a,\"/\"); print a[1]; exit }'",
                     next_tailscale_ip, sizeof(next_tailscale_ip), "offline");
            int next_system_count = load_beszel_systems(next_systems, MAX_BESZEL_SYSTEMS);
            if (strcmp(normal_ip, next_normal_ip) != 0 ||
                strcmp(tailscale_ip, next_tailscale_ip) != 0 ||
                !same_beszel_systems(systems, system_count, next_systems, next_system_count)) {
                snprintf(normal_ip, sizeof(normal_ip), "%s", next_normal_ip);
                snprintf(tailscale_ip, sizeof(tailscale_ip), "%s", next_tailscale_ip);
                memcpy(systems, next_systems, sizeof(next_systems));
                system_count = next_system_count;
                needs_redraw = 1;
            }
        }
        if (needs_redraw) {
            draw_dashboard(back_cr, attrs.width, attrs.height, host, normal_ip, tailscale_ip,
                           systems, system_count);
            cairo_set_source_surface(cr, back_surface, 0, 0);
            cairo_paint(cr);
            cairo_surface_flush(surface);
            XFlush(display);
            needs_redraw = 0;
        }
        counter++;
        sleep(1);
    }

    cairo_destroy(cr);
    cairo_destroy(back_cr);
    cairo_surface_destroy(back_surface);
    cairo_surface_destroy(surface);
    XCloseDisplay(display);
    return 0;
}
