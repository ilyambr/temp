#!/usr/bin/env bash
set -euo pipefail

exec rsync -a --delete \
  --exclude '.git/' \
  --exclude '.codex/' \
  -e 'ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new' \
  --rsync-path='sudo rsync' \
  /home/codex/homelab/ \
  'codex@100.107.137.7:/srv/samba/server/Codex Script Archive/C/Users/Administrator/Documents/Homelab/'
